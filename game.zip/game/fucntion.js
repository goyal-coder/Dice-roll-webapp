let inputNum;
let count = 0;
let sum = 0;
let diceImage = [
    "dice1.png",
    "dice2.png",
    "dice3.png",
    "dice4.png",
    "dice5.png",
    "dice6.png"
];

// Function to roll the dice and return the chosen image
function rollDice() {
    let chooseImage = Math.floor(Math.random() * diceImage.length);
    let chosen = diceImage[chooseImage];  // ✅ Select random dice image
    document.getElementById("images").innerHTML = `<img src="${chosen}" alt="Dice Image" class="dice-img" style="width: 100px; height: 100px ;margin-top:1.5rem;">`;


    console.log("Rolled Image:", chosen); // Debugging

    return chosen;
}

// Function to map dice images to numbers
function getDiceMapping() {
    return {
        "dice1.png": 1,
        "dice2.png": 2,
        "dice3.png": 3,
        "dice4.png": 4,
        "dice5.png": 5,
        "dice6.png": 6
    };
}

// Function to update values when the user inputs a number
function updateVal() {
    inputNum = document.getElementById("number-input").value;
    count = Number(inputNum);
    sum = 0; // ✅ Reset sum for each new roll session

    let imgMapping = getDiceMapping(); // ✅ Get mapping dictionary
    let imagesHTML = ""; // ✅ Store images to display

    for (let i = 0; i < count; i++) {
        let chosenImage = rollDice();  // ✅ Roll dice
        imagesHTML += `<img src="${chosenImage}" alt="Dice Image" class="dice-img">`;

        // ✅ Convert image to a number and add to sum
        if (chosenImage in imgMapping) {
            sum += imgMapping[chosenImage];
        }
    }

    // ✅ Show all rolled images
    document.getElementById("images").innerHTML = imagesHTML;
    
    // ✅ Update total result
    document.getElementById("result").innerHTML = `<p class="result2">Your total is ${sum}</p>`;
}
